var srcIndex = new Map(JSON.parse('[["lab1",["",[],["main.rs"]]],["libc",["",[["unix",[["bsd",[["apple",[["b64",[["x86_64",[],["mod.rs"]]],["mod.rs"]]],["mod.rs"]]],["mod.rs"]]],["mod.rs"]]],["lib.rs","macros.rs","primitives.rs"]]]]'));
createSrcSidebar();
//{"start":36,"fragment_lengths":[28,167]}